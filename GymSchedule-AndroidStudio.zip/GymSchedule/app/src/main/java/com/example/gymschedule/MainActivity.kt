package com.example.gymschedule

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.delay

private data class Exercise(val name:String, val group:String)
private data class DayPlan(val day:String,val title:String,val exercises:List<Exercise>)
private data class SetState(var reps:String="", var done:Boolean=false)
private data class ExState(val exercise:Exercise, val sets:MutableList<SetState>)
private data class HistoryItem(val date:String,val title:String,val exercises:Int,val sets:Int,val reps:Int,val duration:String)

private val push=listOf("Barbell Flat Bench Press","Dumbbell Incline Bench Press","Pec Fly","Upper-Grip Chest Machine","High Cable Fly","Shoulder Press Machine / Barbell Shoulder Press","Lateral Raises","Rear Delt Fly","Triceps Pushdown","Overhead Triceps Extension")
private val pull=listOf("Wide-Grip Lat Pulldown","Seated Row","T-Bar Row","Rowing","Deadlift","Shrugs","Standard Biceps Curl","Incline Biceps Curl","Hammer Curl","Forearm Curl")
private val lower=listOf("Squat","Leg Press","Leg Extension","Lying Leg Curl","Calf Raises","Sit-Up / Crunch","Leg Raises")
private val upper=listOf("Barbell Bench Press","Dumbbell Incline Bench Press","Lat Pulldown","Seated Row","Shrugs","Shoulder Press","Lateral Raises","Rear Delt Fly","Standard Biceps Curl","Hammer Curl","Triceps Pushdown","Overhead Triceps Extension")
private fun exs(names:List<String>)=names.mapIndexed{ i,n->Exercise(n, when{ i<5&&names===push->"Chest"; names===pull&&i<5->"Back"; names===upper&&i<2->"Chest"; names===upper&&i<4->"Back"; names===upper&&i==4->"Traps"; names===upper&&i in 5..7->"Shoulders"; names===upper&&i in 8..9->"Biceps"; names===upper->"Triceps"; names===lower&&i<5->"Legs"; else->if(names===pull&&i==5)"Traps" else if(names===pull&&i in 6..8)"Biceps" else "Forearms" })}
private val plans=listOf(DayPlan("MONDAY","Push Day",exs(push)),DayPlan("TUESDAY","Pull Day",exs(pull)),DayPlan("WEDNESDAY","Leg Day",exs(lower)),DayPlan("THURSDAY","Upper Body",exs(upper)),DayPlan("FRIDAY","Lower Body",exs(lower)),DayPlan("SATURDAY","Rest",emptyList()),DayPlan("SUNDAY","Rest",emptyList()))

class GymVM:ViewModel(){
    var screen by mutableStateOf("Home"); var selected by mutableStateOf(0); var defaultSets by mutableIntStateOf(3); var restSeconds by mutableIntStateOf(90); var dark by mutableStateOf(true)
    var states by mutableStateOf(emptyList<ExState>()); var history by mutableStateOf(emptyList<HistoryItem>()); var timerRunning by mutableStateOf(false); var timerLeft by mutableLongStateOf(90); var startedAt by mutableLongStateOf(0L)
    init{ load(0) }
    fun load(index:Int){ selected=index; states=plans[index].exercises.map{ExState(it,MutableList(defaultSets){SetState()})} }
    fun addSet(i:Int){states=states.mapIndexed{idx,e->if(idx==i)e.copy(sets=(e.sets+SetState()).toMutableList()) else e}}
    fun removeSet(i:Int){states=states.mapIndexed{idx,e->if(idx==i&&e.sets.size>1)e.copy(sets=e.sets.dropLast(1).toMutableList()) else e}}
    fun toggle(i:Int,s:Int){val n=states.mapIndexed{idx,e->if(idx==i){val ss=e.sets.map{it.copy()}.toMutableList();ss[s].done=!ss[s].done;e.copy(sets=ss)}else e};states=n}
    fun reps(i:Int,s:Int,v:String){val n=states.mapIndexed{idx,e->if(idx==i){val ss=e.sets.map{it.copy()}.toMutableList();ss[s].reps=v;e.copy(sets=ss)}else e};states=n}
    fun startTimer(){timerLeft=restSeconds.toLong();timerRunning=true}; fun pause(){timerRunning=false}; fun reset(){timerRunning=false;timerLeft=restSeconds.toLong()}; fun skip(){timerRunning=false;timerLeft=0}
    fun complete(){val now=Date();val f=SimpleDateFormat("dd MMM yyyy",Locale.getDefault());history=listOf(HistoryItem(f.format(now),plans[selected].title,states.size,states.sumOf{it.sets.count{ s->s.done}},states.sumOf{it.sets.sumOf{s->s.reps.toIntOrNull()?:0}},"—"))+history;screen="History"}
    fun clear(){history=emptyList();load(selected)}
}

@Composable fun App(vm:GymVM=viewModel()){
    LaunchedEffect(timerRunning){while(vm.timerRunning&&vm.timerLeft>0){delay(1000);vm.timerLeft--};if(vm.timerLeft<=0)vm.timerRunning=false}
    MaterialTheme(colorScheme=darkScheme){Scaffold(containerColor=Color(0xFF0B0D10),bottomBar={NavigationBar(containerColor=Color(0xFF111419)){listOf("Home","Workout","History","Settings").forEach{n->NavigationBarItem(selected=vm.screen==n,onClick={vm.screen=n;if(n=="Workout")vm.load(vm.selected)},icon={Text(if(n=="Home")"⌂" else if(n=="Workout")"◆" else if(n=="History")"◷" else "⚙",fontSize=20.sp)},label={Text(n)})}}}){pad->Box(Modifier.padding(pad).fillMaxSize()){when(vm.screen){"Home"->Home(vm);"Workout"->Workout(vm);"History"->History(vm);else->Settings(vm)}}}}
}
private val darkScheme=darkColorScheme(primary=Color(0xFFFF6B35),secondary=Color(0xFFFFA45B),background=Color(0xFF0B0D10),surface=Color(0xFF15191F))
@Composable fun Title(t:String,sub:String=""){Column(Modifier.padding(20.dp)){Text(t.uppercase(),fontSize=28.sp,fontWeight=FontWeight.ExtraBold);if(sub.isNotEmpty())Text(sub,color=Color.Gray,modifier=Modifier.padding(top=3.dp))}}
@Composable fun Home(vm:GymVM){val cal=Calendar.getInstance();val idx=cal.get(Calendar.DAY_OF_WEEK)-Calendar.MONDAY;val today=if(idx in 0..6)idx else 6;Column{Title("Gym Schedule","Your weekly training plan") ;LazyColumn(Modifier.weight(1f).padding(horizontal=16.dp)){itemsIndexed(plans){i,p->Card(onClick={vm.load(i);vm.screen="Workout"},colors=CardDefaults.cardColors(containerColor=if(i==today)Color(0xFF272018) else Color(0xFF15191F)),shape=RoundedCornerShape(18.dp),modifier=Modifier.padding(bottom=10.dp).fillMaxWidth()){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(p.day,fontWeight=FontWeight.Bold,color=if(i==today)Color(0xFFFF8A55) else Color.Gray);Text(p.title,fontSize=19.sp,fontWeight=FontWeight.Bold)}}}}};if(plans[today].exercises.isEmpty())Text("REST DAY 😴",fontSize=22.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp));else Button(onClick={vm.load(today);vm.screen="Workout"},modifier=Modifier.fillMaxWidth().padding(16.dp).height(54.dp),shape=RoundedCornerShape(15.dp)){Text("START TODAY'S WORKOUT")}}}
@Composable fun Workout(vm:GymVM){val p=plans[vm.selected];val done=vm.states.count{it.sets.all{s->s.done}};Column{Title(p.title,"$done / ${vm.states.size} exercises completed");LinearProgressIndicator(progress={if(vm.states.isEmpty())0f else done.toFloat()/vm.states.size},modifier=Modifier.fillMaxWidth().padding(horizontal=20.dp),color=Color(0xFFFF6B35));if(p.exercises.isEmpty()){Text("REST DAY 😴",fontSize=26.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(24.dp));return};LazyColumn(Modifier.weight(1f).padding(16.dp)){itemsIndexed(vm.states){i,e->Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF15191F)),shape=RoundedCornerShape(18.dp),modifier=Modifier.padding(bottom=12.dp).fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("${i+1}. ${e.exercise.name}",fontWeight=FontWeight.Bold,fontSize=17.sp);e.sets.forEachIndexed{s,set->Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(top=9.dp)){Text("Set ${s+1}",Modifier.width(52.dp));OutlinedTextField(value=set.reps,onValueChange={vm.reps(i,s,it.filter(Char::isDigit))},modifier=Modifier.width(110.dp),singleLine=true,label={Text("Reps")});Spacer(Modifier.width(8.dp));Checkbox(checked=set.done,onCheckedChange={vm.toggle(i,s)});if(set.done)Text("✓",color=Color(0xFFFF6B35))}};Row{TextButton(onClick={vm.addSet(i)}){Text("+ Add Set")};if(e.sets.size>1)TextButton(onClick={vm.removeSet(i)}){Text("Remove")}};if(e.sets.any{it.done})Button(onClick={vm.startTimer},modifier=Modifier.fillMaxWidth()){Text("START REST TIMER")}}}}};if(done==vm.states.size)Button(onClick={vm.complete},modifier=Modifier.fillMaxWidth().padding(16.dp)){Text("WORKOUT COMPLETE 🔥")}}
@Composable fun TimerDialog(vm:GymVM){if(vm.timerRunning||vm.timerLeft<vm.restSeconds){AlertDialog(onDismissRequest={vm.pause()},confirmButton={},title={Text("REST TIMER")},text={Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.fillMaxWidth()){Text(String.format("%02d:%02d",vm.timerLeft/60,vm.timerLeft%60),fontSize=52.sp,fontWeight=FontWeight.ExtraBold);Row{Button(onClick={vm.pause()}){Text("PAUSE")};Spacer(Modifier.width(8.dp));Button(onClick={vm.reset}){Text("RESET")};Spacer(Modifier.width(8.dp));Button(onClick={vm.skip}){Text("SKIP")}};if(vm.timerLeft==0L)Text("REST COMPLETE!",fontWeight=FontWeight.Bold,color=Color(0xFFFF6B35));else Text("${vm.restSeconds} sec rest",color=Color.Gray)}})}}
@Composable fun History(vm:GymVM){Column{Title("History","Completed workouts stored on this device");if(vm.history.isEmpty())Text("No completed workouts yet.",color=Color.Gray,modifier=Modifier.padding(20.dp));else LazyColumn(Modifier.padding(16.dp)){items(vm.history){h->Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF15191F)),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth().padding(bottom=10.dp)){Column(Modifier.padding(17.dp)){Text("${h.date} — ${h.title}",fontWeight=FontWeight.Bold);Text("${h.exercises} exercises • ${h.sets} sets • ${h.reps} reps",color=Color.Gray);Text("Duration: ${h.duration}",color=Color.Gray)}}}}}}
@Composable fun Settings(vm:GymVM){Column{Title("Settings","Local-only preferences");Text("Default sets",fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp,10.dp));Row(Modifier.padding(horizontal=20.dp)){Button(onClick={vm.defaultSets=3;vm.load(vm.selected)}){Text("3")};Spacer(Modifier.width(8.dp));Button(onClick={vm.defaultSets=4;vm.load(vm.selected)}){Text("4")}};Text("Default rest timer",fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp,20.dp,20.dp,10.dp));Row(Modifier.padding(horizontal=20.dp)){listOf(30,60,90,120,180).forEach{v->TextButton(onClick={vm.restSeconds=v;vm.timerLeft=v.toLong()}){Text("${v}s")}}};Button(onClick={vm.clear},modifier=Modifier.padding(20.dp)){Text("RESET WORKOUT / HISTORY")}}}

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
